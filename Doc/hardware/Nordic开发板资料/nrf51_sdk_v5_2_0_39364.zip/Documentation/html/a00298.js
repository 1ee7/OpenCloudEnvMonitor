var a00298 =
[
    [ "char_handles", "a00298.html#a3f137cc3f92bf439d93a8491e4314d5a", null ],
    [ "ref_handle", "a00298.html#a0209468bba2c298192f4500a652dd6d1", null ]
];