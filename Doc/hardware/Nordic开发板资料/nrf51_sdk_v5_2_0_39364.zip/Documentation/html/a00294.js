var a00294 =
[
    [ "b_country_code", "a00294.html#aadd0326cc45c31ea9e16b2f4cf0000fd", null ],
    [ "bcd_hid", "a00294.html#a077bfa68d00dff20a7497f8f7936ae79", null ],
    [ "flags", "a00294.html#acec5c1f0cd643c04bce7a9542e1b7444", null ],
    [ "security_mode", "a00294.html#ad011fc0114c033fc712bce4491101ac1", null ]
];