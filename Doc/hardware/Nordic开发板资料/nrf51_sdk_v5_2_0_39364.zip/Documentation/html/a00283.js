var a00283 =
[
    [ "params", "a00283.html#a4a2425d586dcbf49892df06e93999322", null ],
    [ "params", "a00283.html#a64b3451e47833a40bf10d9b7b0c64b48", null ],
    [ "params", "a00283.html#a64958567c6c5dd50658bee8fb7bca339", null ],
    [ "read", "a00283.html#a7d0c5d0586fa2a048d724a7ededf5e18", null ],
    [ "type", "a00283.html#a70efda4990b7c7e43bc7c0b1ae75c05e", null ],
    [ "write", "a00283.html#aa536efc6b3a866b5ae2d4c6cd9b2aafa", null ]
];