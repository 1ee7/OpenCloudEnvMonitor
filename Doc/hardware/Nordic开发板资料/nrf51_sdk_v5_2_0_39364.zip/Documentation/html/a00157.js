var a00157 =
[
    [ "baud_rate", "a00157.html#aed401d2ee067394f8996bd5c0f4ff894", null ],
    [ "cts_pin_no", "a00157.html#afd55bb9fe47cfd5eff8b468083b2dfed", null ],
    [ "flow_control", "a00157.html#a0f003e30e3587f068bf45fad9f99bbc4", null ],
    [ "rts_pin_no", "a00157.html#a836f131cb64d3cdf9831c0354483a65f", null ],
    [ "rx_pin_no", "a00157.html#a30ae0cdf9181248fa08411af42a938a9", null ],
    [ "tx_pin_no", "a00157.html#a7153a5ce2ab2d164224a7a17d5b1c56c", null ],
    [ "use_parity", "a00157.html#a0851da050a073c86c13d0734e78f9d97", null ]
];