var a00180 =
[
    [ "blood_pressure_diastolic", "a00180.html#aed7e0a29d6cda87a84a69f4f7551fb6c", null ],
    [ "blood_pressure_systolic", "a00180.html#ab097c85436eecc592213cdb75435f596", null ],
    [ "blood_pressure_units_in_kpa", "a00180.html#a3d4f46ef4a031f2c849bba6ac9d68ba3", null ],
    [ "mean_arterial_pressure", "a00180.html#a2455e564b8569f3f3bc999420efa7c1d", null ],
    [ "measurement_status", "a00180.html#aa825f66cc38338e2f8bb4f767cdc8805", null ],
    [ "measurement_status_present", "a00180.html#a80874044508391d1569ff1c476a4b5a7", null ],
    [ "pulse_rate", "a00180.html#a4cec6cfcf650361edada4efe2d612461", null ],
    [ "pulse_rate_present", "a00180.html#adcd3739c6e00a92c9c9026894e4248b8", null ],
    [ "time_stamp", "a00180.html#a5724947dd197246dea1db93935a24b32", null ],
    [ "time_stamp_present", "a00180.html#a5ed42a9cdaf140e3e18dc44e1b1baa5b", null ],
    [ "user_id", "a00180.html#a68b822db90d51c550cddfb74fec7b1a7", null ],
    [ "user_id_present", "a00180.html#a48e9ed959366ea1e7c7c8bb284a01979", null ]
];