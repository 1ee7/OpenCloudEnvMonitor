var a00251 =
[
    [ "handle", "a00251.html#ada1f0c9228867fd73fd596d6d7241c67", null ],
    [ "uuid", "a00251.html#a039854704d107784b185fb11b00b1258", null ]
];