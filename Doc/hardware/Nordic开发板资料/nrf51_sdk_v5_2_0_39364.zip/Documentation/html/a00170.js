var a00170 =
[
    [ "batt_level", "a00170.html#a2ee0ae0059fdf3db401bccde6c08f5d3", null ],
    [ "evt_type", "a00170.html#a19f2646a4734d1fc7cb27fdd7055fa55", null ],
    [ "params", "a00170.html#ad2d18a81b0294d66fefe1e60eeda0be0", null ]
];