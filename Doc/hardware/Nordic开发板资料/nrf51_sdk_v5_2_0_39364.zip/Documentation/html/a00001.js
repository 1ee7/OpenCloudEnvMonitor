var a00001 =
[
    [ "Setups", "a00093.html", [
      [ "Evaluation Board Setup (PCA10001/PCA10003)", "a00093.html#ble_sdk_apps_setup_eval", null ],
      [ "nRFgo Motherboard Setup (nRF6310)", "a00093.html#nrf51_setup_nrf6310", null ],
      [ "nRFgo Motherboard Setup - Serialization", "a00093.html#nrf51_setups_serialization", [
        [ "Terminology", "a00093.html#nrf51_setup_nrf6310_serialization_terminology", null ],
        [ "nRFgo Motherboard Setup (nRF6310)", "a00093.html#nrf51_setup_nrf6310_serialization", null ],
        [ "Prepare nRF51822 boards", "a00093.html#nrf51_flashing_nrf6310_serialization", null ],
        [ "Flashing of nRF51822 Connectivity Chip software", "a00093.html#nrf51_conn_chip_flashing_nrf6310_serialization", null ],
        [ "Flashing of Serialized <i>Bluetooth</i> Application", "a00093.html#nrf51_app_flashing_nrf6310_serialization", null ],
        [ "Verifying the application", "a00093.html#nrf51_board_reset_serialization", null ],
        [ "GPIO Pin assignments", "a00093.html#nrf51_pins_nrf6310_serialization", null ]
      ] ]
    ] ]
];