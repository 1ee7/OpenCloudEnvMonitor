var a00098 =
[
    [ "Alert Notification Service Client", "a00112.html", null ],
    [ "Battery Service", "a00113.html", null ],
    [ "Blood Pressure Service", "a00114.html", null ],
    [ "Cycling Speed and Cadence Service", "a00115.html", null ],
    [ "Device Information Service", "a00116.html", null ],
    [ "Glucose Service", "a00117.html", [
      [ "Glucose Service", "a00117.html#section_glucose_service", null ],
      [ "Glucose Service Database", "a00117.html#section_glucose_service_db", null ]
    ] ],
    [ "Health Thermometer Service", "a00118.html", null ],
    [ "Heart Rate Service", "a00119.html", null ],
    [ "Human Interface Device Service", "a00120.html", null ],
    [ "Human Immediate Alert Service", "a00121.html", null ],
    [ "Human Immediate Alert Service Client", "a00122.html", null ],
    [ "Link Loss Service", "a00123.html", null ],
    [ "Running Speed and Cadence Service", "a00124.html", null ],
    [ "TX Power Service", "a00125.html", null ]
];