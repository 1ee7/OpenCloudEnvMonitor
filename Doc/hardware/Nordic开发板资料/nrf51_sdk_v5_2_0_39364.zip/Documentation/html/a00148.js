var a00148 =
[
    [ "bytes", "a00148.html#a12b21adb380c5aedfee8d3c6d66f4a4a", null ],
    [ "crc", "a00148.html#a4b15238a7baaf9c17340d956d3db0072", null ],
    [ "data", "a00148.html#a928d24a424a17a680e29c2e9fc75626b", null ],
    [ "event", "a00148.html#affb34693937c93740c7c464bd9f4225c", null ],
    [ "file_index", "a00148.html#a2750fad8d7a5e678cf988c1a07eda288", null ],
    [ "offset", "a00148.html#a3c9653e515833bafb75b16569fb1cd18", null ]
];