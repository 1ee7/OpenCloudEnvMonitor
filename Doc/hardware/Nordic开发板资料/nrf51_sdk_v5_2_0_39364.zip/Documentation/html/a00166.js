var a00166 =
[
    [ "alert", "a00166.html#a1516abb33b9dfe3d7ea721f893f3cc7e", null ],
    [ "data", "a00166.html#a3deb4df9757dde953727e1017a0bfc69", null ],
    [ "error_code", "a00166.html#ab6e81a948852e8f1c27d25166815c9eb", null ],
    [ "evt_type", "a00166.html#a933154cfde918e82cccf331250f23251", null ],
    [ "settings", "a00166.html#af0183eb636b54d11dedd0b44471ecf68", null ],
    [ "uuid", "a00166.html#a5291a39d334459d01eb8c359ce40eaf6", null ]
];