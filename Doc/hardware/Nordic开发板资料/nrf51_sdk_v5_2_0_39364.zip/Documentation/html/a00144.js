var a00144 =
[
    [ "__pad0__", "a00144.html#ab4f2a7e61e7a0ce6a633cf0f2a58ca15", null ],
    [ "is_data_available", "a00144.html#aae78aad96dbff8f314bd6d571acbd5eb", null ],
    [ "is_pairing_enabled", "a00144.html#ab846352c7654d97a1f286f7875a4d90a", null ],
    [ "is_upload_enabled", "a00144.html#aa3b2d73c44dd430b1a598296585cce53", null ],
    [ "link_period", "a00144.html#ab940ce0cfc0f501612bc7b83ba5ea521", null ],
    [ "parameters", "a00144.html#a108f587d58930f95c418accb8a2c8197", null ],
    [ "status", "a00144.html#af790c38f19ec740f60ec72151cb66161", null ]
];