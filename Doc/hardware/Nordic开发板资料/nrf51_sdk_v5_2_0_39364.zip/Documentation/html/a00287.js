var a00287 =
[
    [ "carbohydrate", "a00287.html#a9beb857a6df2f0813640626d818c4e4d", null ],
    [ "carbohydrate_id", "a00287.html#a323005a484d605979ee196edc65b565a", null ],
    [ "exercise_duration", "a00287.html#a8d38fe5be64903f80f797630db249455", null ],
    [ "exercise_intensity", "a00287.html#ad339663b61c39d8d1c547def62931771", null ],
    [ "extended_flags", "a00287.html#a44cd84da95e919dfd61bf31e8e582e27", null ],
    [ "flags", "a00287.html#aeb34e1ef25f19e2bfaf246df822b2cea", null ],
    [ "hba1c", "a00287.html#a509541df40935394dbaee9c1d4cab4f6", null ],
    [ "meal", "a00287.html#a5f9f2d7f29fea28f00c9771f8bf8138d", null ],
    [ "medication", "a00287.html#a6fbcf26226c924ca64c94fb52659eaa6", null ],
    [ "medication_id", "a00287.html#adf0ae945c97e9a34a1c6ae48b90eac8d", null ],
    [ "tester_and_health", "a00287.html#ac05ff23f10d9438197ae912cb4cec6b1", null ]
];