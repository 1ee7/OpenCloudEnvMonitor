var a00240 =
[
    [ "active", "a00240.html#a7f3eda85d15916ad467a81faba18f076", null ],
    [ "filter", "a00240.html#a0be3f012ef37a3bfca076cffab526f68", null ],
    [ "interval", "a00240.html#a086b92604899521d85052d48d8552b7d", null ],
    [ "p_whitelist", "a00240.html#a2c611522e99e67bd89d484bc2ad96463", null ],
    [ "selective", "a00240.html#abbe25b20112d8859f9ceff46b5711651", null ],
    [ "timeout", "a00240.html#a1ddedc25ebdb29351a7cbd0039ce6ed8", null ],
    [ "window", "a00240.html#a89a91dffe2c1b7edc26567c932a491b7", null ]
];