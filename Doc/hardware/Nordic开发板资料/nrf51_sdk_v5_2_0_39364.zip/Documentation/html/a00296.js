var a00296 =
[
    [ "max_len", "a00296.html#a656fc246bd9f18026083e3efb640052e", null ],
    [ "rep_ref", "a00296.html#aeb77c0bc0738fbb0be766e574ac173b5", null ],
    [ "security_mode", "a00296.html#a757afd0e411e7e67224c94fefcf26bab", null ]
];