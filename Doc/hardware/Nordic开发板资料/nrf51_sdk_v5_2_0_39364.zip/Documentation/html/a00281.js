var a00281 =
[
    [ "handle", "a00281.html#a1a0552b266c588f67d3a6abc712bbfd6", null ],
    [ "offset", "a00281.html#a07033f6e0e63974b67627ae84bc12fc9", null ],
    [ "p_data", "a00281.html#a5acc03f7f6a291606eac3531d7c642e4", null ],
    [ "p_len", "a00281.html#a7ebb8ac9d923f05118216aa191d93a9c", null ],
    [ "type", "a00281.html#a2971c791821bea067f3bc2bbc35b9193", null ]
];