var a00275 =
[
    [ "context", "a00275.html#a66d632e13cd7d371036af6a90be224f4", null ],
    [ "handle", "a00275.html#a79c55f70b9d10f1e11b35bb2cc13fdbd", null ],
    [ "offset", "a00275.html#ac3c5c0c840625a5f28e90e9021eb2403", null ]
];