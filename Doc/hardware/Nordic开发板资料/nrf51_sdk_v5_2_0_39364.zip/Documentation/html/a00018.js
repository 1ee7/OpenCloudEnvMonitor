var a00018 =
[
    [ "Device/Host example", "a00033.html", [
      [ "Host", "a00033.html#Host", null ],
      [ "Device", "a00033.html#Device", null ]
    ] ],
    [ "Desktop device emulator", "a00032.html", null ],
    [ "Pairing Device with Dynamic Pairing", "a00034.html", [
      [ "Device pairing", "a00034.html#gzll_example_gzp_pairing_section_device", null ],
      [ "Host pairing", "a00034.html#gzll_example_gzp_pairing_section_host", null ]
    ] ]
];