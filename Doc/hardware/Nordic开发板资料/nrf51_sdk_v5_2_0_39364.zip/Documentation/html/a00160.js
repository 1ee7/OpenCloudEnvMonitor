var a00160 =
[
    [ "company_identifier", "a00160.html#a82bb52823dc2e6f1d5da1103e90eb34f", null ],
    [ "data", "a00160.html#ac19b78af581334531c4b7eff27494ea3", null ]
];