var a00150 =
[
    [ "file_crc", "a00150.html#a54e1f19464c414acdfecd0373d0fdaf2", null ],
    [ "file_index", "a00150.html#a97a6649143c049c976c5194bc88f121e", null ],
    [ "file_size", "a00150.html#a40c605e8297e5b0a61e3926240b4d305", null ],
    [ "max_burst_block_size", "a00150.html#a3723cd1509d58c1f76aabd958cf217f6", null ],
    [ "max_file_size", "a00150.html#af55733b64b716ed3a5c361c6f6c602f4", null ]
];