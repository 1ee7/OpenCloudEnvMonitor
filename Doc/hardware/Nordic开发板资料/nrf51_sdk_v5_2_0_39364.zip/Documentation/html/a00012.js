var a00012 =
[
    [ "BLE Multi-link Example", "a00085.html", [
      [ "Functionality.", "a00085.html#project_intro", null ],
      [ "Setup", "a00085.html#project_multilink_setup", [
        [ "Button and LED Assignments", "a00085.html#project_multilink_setup_buttons_leds", null ]
      ] ],
      [ "Functionality", "a00085.html#functionality", [
        [ "Porting the central example to run on evaluation board", "a00085.html#project_multilink_porting_to_eval", null ]
      ] ],
      [ "Testing", "a00085.html#project_multilink_testing", null ]
    ] ],
    [ "BLE Heart Rate Collector Example", "a00083.html", [
      [ "Functionality", "a00083.html#ble_hrc_intro", null ],
      [ "LED Assignments", "a00083.html#project_hrc_setup", null ],
      [ "Testing", "a00083.html#ble_hrc_test", null ]
    ] ]
];