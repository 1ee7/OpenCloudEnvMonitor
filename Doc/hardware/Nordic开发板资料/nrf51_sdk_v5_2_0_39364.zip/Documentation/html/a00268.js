var a00268 =
[
    [ "char_uuid", "a00268.html#adbbcf41424e48536f3c3e7f2665005fd", null ],
    [ "desc_uuid", "a00268.html#a6d909918be5c3a58a93e3f345ad0ae5e", null ],
    [ "srvc_handle", "a00268.html#a9ec74591a8b40af4354fed5c2ae33efd", null ],
    [ "srvc_uuid", "a00268.html#a351c0654157494b748a0adcba003e42f", null ],
    [ "type", "a00268.html#a59115313e869d01234cc2ed3ab2e25d9", null ],
    [ "value_handle", "a00268.html#a770254b2ade294a3f24fa0db65a2d0fa", null ]
];