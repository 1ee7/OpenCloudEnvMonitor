var a00208 =
[
    [ "common_evt", "a00208.html#a65014fa31bf6c86c113ef47dc929a755", null ],
    [ "evt", "a00208.html#a60733c8b6ff5fcf1ff7ae8974c7e9bf1", null ],
    [ "evt", "a00208.html#a5772519135efe1c00c49efaf34b6358d", null ],
    [ "evt", "a00208.html#afa8e072b2b882500c0fdee46858a5879", null ],
    [ "gap_evt", "a00208.html#a67ca1f9db570d1c2f196c0a316151af5", null ],
    [ "gattc_evt", "a00208.html#a2bdcb3c197239b4e5957d89bb0f26161", null ],
    [ "gatts_evt", "a00208.html#aea997556a147ad5541998f13699e27c1", null ],
    [ "header", "a00208.html#a31f5fb5f33b8020c1b91639d048a6efa", null ],
    [ "l2cap_evt", "a00208.html#a615ab3df54ef7363a90f915d6440ce1a", null ]
];