var a00292 =
[
    [ "char_id", "a00292.html#a778ecea962888dfc1e026fc52526a9a4", null ],
    [ "char_write", "a00292.html#a5b13c88fa4d7e93836f9e323bda07309", null ],
    [ "evt_type", "a00292.html#a51d0ccfb2582557e1863bb12d77e71dc", null ],
    [ "notification", "a00292.html#a9f56ec74945b4af58c793706099c1a5d", null ],
    [ "params", "a00292.html#aab19c8dcaafbd36c0e674d8f23e69d8e", null ]
];