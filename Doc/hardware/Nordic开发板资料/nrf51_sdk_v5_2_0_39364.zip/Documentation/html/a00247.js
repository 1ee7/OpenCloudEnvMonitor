var a00247 =
[
    [ "addr_count", "a00247.html#a8f7d372587ed29005dbfd515103fa6fd", null ],
    [ "irk_count", "a00247.html#a21922578ee2df66befd41e968f8d5af1", null ],
    [ "pp_addrs", "a00247.html#a7cbf554b7a26e5b01f57c381a59e22ff", null ],
    [ "pp_irks", "a00247.html#a173c6f16185f69823bfaca9dda1b420e", null ]
];