var a00004 =
[
    [ "ANT", "a00015.html", "a00015" ],
    [ "ANT Slave & BLE Peripheral", "a00016.html", "a00016" ],
    [ "BLE Peripheral", "a00014.html", "a00014" ],
    [ "Bootloader/DFU", "a00021.html", "a00021" ],
    [ "Direct Test Mode", "a00022.html", "a00022" ],
    [ "Hardware Peripheral Examples", "a00020.html", "a00020" ],
    [ "Nordic proprietary protocols", "a00019.html", "a00019" ]
];