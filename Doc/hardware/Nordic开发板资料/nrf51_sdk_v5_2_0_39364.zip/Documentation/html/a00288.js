var a00288 =
[
    [ "base_time", "a00288.html#a50043eec02a9af09a81047f4eecfef33", null ],
    [ "flags", "a00288.html#adaa211ee17f3d46654c641ab339b68db", null ],
    [ "glucose_concentration", "a00288.html#a8d77eafd69ad69d3753fd043bdd31dc2", null ],
    [ "sample_location", "a00288.html#a21eed1c3fbda85ac65aa060787a589b4", null ],
    [ "sensor_status_annunciation", "a00288.html#a765f2b453e27775757271598452e2c8a", null ],
    [ "sequence_number", "a00288.html#a7e89e39efc4889fc00da13fa87efcbc2", null ],
    [ "time_offset", "a00288.html#a820a55933ac2e9e047193a846efbaf5d", null ],
    [ "type", "a00288.html#a4e79195531cf78dfd880479a6404cb44", null ]
];