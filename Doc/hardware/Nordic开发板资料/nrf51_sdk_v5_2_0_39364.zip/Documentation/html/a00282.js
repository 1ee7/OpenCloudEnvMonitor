var a00282 =
[
    [ "gatt_status", "a00282.html#a76066ec0dfed065ff7e58a709eaf8042", null ],
    [ "len", "a00282.html#a5242203755359060a29308d0e64b6da7", null ],
    [ "offset", "a00282.html#a7b823765dc8e01aa1dfc9a3124f92bc9", null ],
    [ "p_data", "a00282.html#a0a6e536bf76b7d15a1748880c657e55b", null ],
    [ "update", "a00282.html#a27015e208127d98d0600657e4f9224fc", null ]
];