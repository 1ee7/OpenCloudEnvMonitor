var a00252 =
[
    [ "chars", "a00252.html#a8f1cd7326b1e7b041c3f45d71f19f28f", null ],
    [ "count", "a00252.html#a91337d714a569e896c896a3b255db8ff", null ]
];