var a00238 =
[
    [ "ch_map", "a00238.html#a71bb5ea1d8eecc86f819a1f5a3807818", null ],
    [ "conn_handle", "a00238.html#adbf93719ab5531a19758504bdeb6c469", null ]
];