var a00262 =
[
    [ "data", "a00262.html#a662dfe4b34cb8ccb0e29521d1a2e04b6", null ],
    [ "handle", "a00262.html#ae8e1aafaf1cbc9b6f7b5fcd163dd5cac", null ],
    [ "len", "a00262.html#a323a6805f77fe47c890cde179ea2f674", null ],
    [ "offset", "a00262.html#a09d38782fd5d200a45146ae303614733", null ],
    [ "write_op", "a00262.html#a7cbd3dd7ab5f53b8f14e023b9c0c2db6", null ]
];