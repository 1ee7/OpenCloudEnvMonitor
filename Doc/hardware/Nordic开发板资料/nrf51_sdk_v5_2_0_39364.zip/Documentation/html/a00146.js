var a00146 =
[
    [ "data_file_index", "a00146.html#a2f7dcfd079302cd55e539abb2e2bf621", null ],
    [ "date", "a00146.html#a12fec01b1ad1c0ddfff45a581a5541ef", null ],
    [ "file_data_type", "a00146.html#a3de3b2fe3be4ccfdf9c73dbed382c0de", null ],
    [ "file_size_in_bytes", "a00146.html#aeba8fd2a28825e717f8219b6da204661", null ],
    [ "general_flags", "a00146.html#a7f98e8db6bbd2405683348e07fd158fb", null ],
    [ "user_defined1", "a00146.html#ac385c84a8c1862b97228eddb4d90fcc7", null ],
    [ "user_defined2", "a00146.html#acbb7884500fe9c0fe071c0daa87f6483", null ],
    [ "user_flags", "a00146.html#af7ffb6c4ad7a854066ced1832056abad", null ]
];