var a00190 =
[
    [ "cumulative_crank_revs", "a00190.html#abaf971426cea9d234838ad3896a5ebb0", null ],
    [ "cumulative_wheel_revs", "a00190.html#a28e443636699abf5ac97850f4fb9eb39", null ],
    [ "is_crank_rev_data_present", "a00190.html#a6750c3a77be5be56ef6e563164b85a4a", null ],
    [ "is_wheel_rev_data_present", "a00190.html#ae78a3f62b14426e5a3fcc65d5cc54d7c", null ],
    [ "last_crank_event_time", "a00190.html#a5ddda2de7f892024636795e85b9ba914", null ],
    [ "last_wheel_event_time", "a00190.html#ab1b12075f983b9149eacf65f318f0482", null ]
];