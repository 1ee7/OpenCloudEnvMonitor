var a00196 =
[
    [ "char_count", "a00196.html#a199d43a17b0e41d7904da316db6b98ae", null ],
    [ "charateristics", "a00196.html#aeeb1c850a101a81108ca109c2f117166", null ],
    [ "handle_range", "a00196.html#a2300f7ac7bc453bc13fb060d3ff05efc", null ],
    [ "srv_uuid", "a00196.html#a97887d3332bca8ac17806b8d328e4a2c", null ]
];