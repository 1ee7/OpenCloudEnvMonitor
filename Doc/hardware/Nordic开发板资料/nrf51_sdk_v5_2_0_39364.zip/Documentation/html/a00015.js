var a00015 =
[
    [ "Broadcast", "a00088.html", [
      [ "ANT Broadcast TX", "a00088.html#ant_broadcast_tx", [
        [ "Description", "a00088.html#Description", null ]
      ] ],
      [ "ANT Broadcast RX", "a00088.html#ant_broadcast_rx", null ],
      [ "References", "a00088.html#References", null ]
    ] ],
    [ "ANT-FS", "a00089.html", [
      [ "ANT FS client", "a00089.html#ant_fs_client", null ]
    ] ],
    [ "Heart Rate", "a00090.html", [
      [ "Receiver", "a00090.html#ant_hrm_receiver", null ],
      [ "Transmitter", "a00090.html#ant_hrm_tx", null ],
      [ "Transmitter with buttons", "a00090.html#ant_hrm_tx_buttons", null ]
    ] ],
    [ "Speed and Cadence", "a00091.html", [
      [ "Receiver", "a00091.html#ant_sdm_rx", null ],
      [ "Transmitter", "a00091.html#ant_sdm_tx", null ]
    ] ],
    [ "Bicycle Speed and Cadence", "a00087.html", [
      [ "Speed and Cadence Sensor", "a00087.html#ant_speed_and_cadence_rx", null ]
    ] ],
    [ "Bicycle Power", "a00086.html", [
      [ "Minimum Receiver", "a00086.html#ant_bicycle_min_rec", null ],
      [ "Power-only sensor", "a00086.html#ant_bicycle_power_only_sensor", null ]
    ] ]
];