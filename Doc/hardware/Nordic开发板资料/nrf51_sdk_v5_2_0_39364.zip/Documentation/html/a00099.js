var a00099 =
[
    [ "HCI transport library", "a00135.html", null ],
    [ "Memory pool library", "a00136.html", null ],
    [ "SLIP handling library", "a00137.html", null ]
];